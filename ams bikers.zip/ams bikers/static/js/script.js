// Global functions for bike operations
async function addToFavorites(bikeId) {
    try {
        const response = await fetch('/api/favorites/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bike_id: bikeId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Added to favorites!', 'success');
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('Error adding to favorites:', error);
        showNotification('Error adding to favorites', 'error');
    }
}

function showBrochure(bike) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    // Add brochure content to PDF
    doc.setFillColor(255, 107, 53);
    doc.rect(0, 0, 210, 40, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text(bike.name, 105, 20, { align: 'center' });
    doc.setFontSize(12);
    doc.text(`${bike.brand} • ${bike.type.toUpperCase()}`, 105, 30, { align: 'center' });
    
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(16);
    doc.text('Specifications', 20, 60);
    doc.setFontSize(10);
    doc.text(`Engine: ${bike.engine}`, 20, 70);
    doc.text(`Mileage: ${bike.mileage}`, 20, 77);
    doc.text(`Price: ${bike.price}`, 20, 84);
    doc.text(`Type: ${bike.type}`, 20, 91);
    
    doc.setFontSize(16);
    doc.text('Key Features', 20, 110);
    doc.setFontSize(10);
    const features = typeof bike.features === 'string' ? JSON.parse(bike.features) : bike.features;
    features.forEach((feature, index) => {
        doc.text(`• ${feature}`, 20, 120 + (index * 7));
    });
    
    doc.setFontSize(12);
    doc.text('For more information, contact:', 20, 180);
    doc.text('📞 1800-AMS-BIKE | 📧 info@amsbikers.com', 20, 187);
    doc.text('AMS Bikers - Your Trusted Bike Partner', 105, 280, { align: 'center' });
    
    // Save the PDF
    doc.save(`${bike.name.replace(/\s+/g, '_')}_Brochure.pdf`);
    
    // Record download
    recordBrochureDownload(bike.bike_id);
}

async function recordBrochureDownload(bikeId) {
    try {
        await fetch('/api/brochure/download', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bike_id: bikeId })
        });
    } catch (error) {
        console.error('Error recording brochure download:', error);
    }
}

function showDealers(bike) {
    // Redirect to dealers page with bike info
    window.location.href = '/dealers';
}

// Notification system
function showNotification(message, type) {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'}-circle"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'success' ? 'var(--success)' : type === 'error' ? 'var(--danger)' : 'var(--primary)'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        z-index: 10000;
        animation: slideInRight 0.3s ease;
        max-width: 300px;
        font-weight: 600;
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Add notification styles to head
const notificationStyles = `
@keyframes slideInRight {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOutRight {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}

.notification-content {
    display: flex;
    align-items: center;
    gap: 10px;
}
`;

// Inject styles
const style = document.createElement('style');
style.textContent = notificationStyles;
document.head.appendChild(style);

// Form validation and utility functions
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[0-9]{10}$/;
    return re.test(phone);
}

// Initialize tooltips and other UI enhancements
document.addEventListener('DOMContentLoaded', function() {
    // Add loading states to all buttons when forms are submitted
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function() {
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn) {
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                submitBtn.disabled = true;
                
                // Revert after 5 seconds (safety net)
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 5000);
            }
        });
    });
});