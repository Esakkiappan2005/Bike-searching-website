from flask import Flask, request, jsonify, session, render_template, redirect, url_for
from flask_cors import CORS
import csv
import os
import hashlib
from datetime import datetime
import json

app = Flask(__name__, template_folder='templates', static_folder='static')
app.secret_key = 'ams_bikers_secret_key_2023'
CORS(app)

# File paths for CSV storage
DATA_DIR = 'data'
USERS_FILE = os.path.join(DATA_DIR, 'users.csv')
CURRENT_BIKES_FILE = os.path.join(DATA_DIR, 'current_bikes.csv')
BIKE_COLLECTION_FILE = os.path.join(DATA_DIR, 'bike_collection.csv')
DISTRICTS_FILE = os.path.join(DATA_DIR, 'districts.csv')
FAVORITES_FILE = os.path.join(DATA_DIR, 'favorites.csv')
BROCHURE_REQUESTS_FILE = os.path.join(DATA_DIR, 'brochure_requests.csv')
RECOMMENDATIONS_FILE = os.path.join(DATA_DIR, 'recommendations.csv')

# Admin credentials (3 admin IDs)
ADMINS = {
    'admin1': 'password123',
    'admin2': 'admin123',
    'superadmin': 'super123'
}

# Initialize CSV files with headers
def init_csv_files():
    # Create data directory if it doesn't exist
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    
    files_config = {
        USERS_FILE: ['user_id', 'name', 'email', 'phone', 'password_hash', 'registration_date'],
        CURRENT_BIKES_FILE: ['bike_id', 'name', 'price', 'image_url', 'engine', 'mileage', 'type', 'brand', 'description', 'features', 'is_recommended'],
        BIKE_COLLECTION_FILE: ['bike_id', 'name', 'price', 'image_url', 'engine', 'mileage', 'type', 'brand', 'description', 'features', 'status', 'added_date'],
        DISTRICTS_FILE: ['district_id', 'name', 'dealers_count', 'contact_info', 'dealer_names'],
        FAVORITES_FILE: ['user_id', 'bike_id', 'added_date'],
        BROCHURE_REQUESTS_FILE: ['request_id', 'user_id', 'bike_id', 'request_date', 'download_count'],
        RECOMMENDATIONS_FILE: ['recommendation_id', 'bike_id', 'priority', 'added_by', 'added_date']
    }
    
    for file_path, headers in files_config.items():
        if not os.path.exists(file_path):
            with open(file_path, 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(headers)
    
    # Initialize with sample data
    init_sample_data()

def init_sample_data():
    # Sample districts with dealer information
    sample_districts = [
        [1, 'Chennai', '15', 'contact-chennai@amsbikers.com', 'TVS Chennai, Honda Showroom, Yamaha Arena, Royal Enfield Flagship'],
        [2, 'Coimbatore', '12', 'contact-coimbatore@amsbikers.com', 'Royal Enfield Coimbatore, Bajaj Motors, KTM Showroom'],
        [3, 'Madurai', '8', 'contact-madurai@amsbikers.com', 'Hero Madurai, Suzuki Plaza, Honda World'],
        [4, 'Trichy', '6', 'contact-trichy@amsbikers.com', 'KTM Trichy, Honda World, Yamaha Center'],
        [5, 'Salem', '5', 'contact-salem@amsbikers.com', 'Yamaha Salem, TVS Motors, Bajaj Arena'],
        [6, 'Tirunelveli', '4', 'contact-tirunelveli@amsbikers.com', 'Royal Enfield Tirunelveli, Hero Showroom'],
        [7, 'Erode', '5', 'contact-erode@amsbikers.com', 'Honda Erode, Suzuki Motors, TVS Plaza'],
        [8, 'Vellore', '4', 'contact-vellore@amsbikers.com', 'Yamaha Vellore, Bajaj Showroom'],
        [9, 'Kanyakumari', '3', 'contact-kanyakumari@amsbikers.com', 'Hero Kanyakumari, Honda Beachside'],
        [10, 'Dindigul', '3', 'contact-dindigul@amsbikers.com', 'Royal Enfield Dindigul, TVS Motors']
    ]
    
    # Sample recommended bikes
    sample_current_bikes = [
        [1, 'Yamaha MT-15', '₹1.67 Lakh', 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80', 
         '155cc', '50 kmpl', 'sports', 'Yamaha', 
         'The Yamaha MT-15 is a streetfighter motorcycle that offers aggressive styling and excellent performance.',
         '["LED Headlights", "Digital Instrument Cluster", "ABS", "Liquid Cooling"]', 'true'],
        
        [2, 'Royal Enfield Classic 350', '₹1.93 Lakh', 'https://images.unsplash.com/photo-1566896506427-72e8fa0b47d1?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
         '349cc', '35 kmpl', 'cruiser', 'Royal Enfield',
         'The Royal Enfield Classic 350 offers timeless design with modern reliability and comfortable cruising.',
         '["Classic Design", "Tripper Navigation", "LED Tail Lamp", "Dual Channel ABS"]', 'true'],
        
        [3, 'KTM Duke 200', '₹1.98 Lakh', 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
         '199.5cc', '35 kmpl', 'naked', 'KTM',
         'The KTM Duke 200 is a lightweight naked street motorcycle with aggressive styling and excellent performance.',
         '["LED Headlights", "TFT Display", "ByBre Calipers", "Steel Trellis Frame"]', 'true']
    ]
    
    # Sample bike collection
    sample_collection_bikes = [
        [101, 'Yamaha R15 V4', '₹1.82 Lakh', 'https://images.unsplash.com/photo-1558979158-89cbc00e55a6?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
         '155cc', '45 kmpl', 'sports', 'Yamaha',
         'The Yamaha R15 V4 is a fully-faired sports bike with track-focused performance and advanced features.',
         '["VVA Technology", "Quick Shifter", "Deltabox Frame", "LCD Display", "LED Lighting"]', 'available', datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
        
        [102, 'Honda SP 125', '₹86,000', 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
         '125cc', '65 kmpl', 'commuter', 'Honda',
         'The Honda SP 125 offers excellent fuel efficiency with premium features and reliable performance.',
         '["All-LED Lighting", "Digital Meter", "HET", "AC Generator", "ES"]', 'available', datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
        
        [103, 'Bajaj Pulsar NS200', '₹1.42 Lakh', 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
         '199.5cc', '40 kmpl', 'sports', 'Bajaj',
         'The Bajaj Pulsar NS200 features a perimeter frame and liquid-cooled engine for excellent performance.',
         '["Liquid Cooling", "Perimeter Frame", "Nitrox Suspension", "Dual Channel ABS"]', 'available', datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
        
        [104, 'TVS Apache RTR 160', '₹1.20 Lakh', 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80',
         '159.7cc', '45 kmpl', 'sports', 'TVS',
         'The TVS Apache RTR 160 offers sporty performance with race-inspired technology and features.',
         '["Glide Through Technology", "Race Tuned Suspension", "Petal Disc Brakes", "Split Seat"]', 'available', datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
    ]
    
    # Write sample data if files are empty
    with open(DISTRICTS_FILE, 'r', encoding='utf-8') as file:
        reader = csv.reader(file)
        if sum(1 for row in reader) <= 1:
            with open(DISTRICTS_FILE, 'a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerows(sample_districts)
    
    with open(CURRENT_BIKES_FILE, 'r', encoding='utf-8') as file:
        reader = csv.reader(file)
        if sum(1 for row in reader) <= 1:
            with open(CURRENT_BIKES_FILE, 'a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerows(sample_current_bikes)
    
    with open(BIKE_COLLECTION_FILE, 'r', encoding='utf-8') as file:
        reader = csv.reader(file)
        if sum(1 for row in reader) <= 1:
            with open(BIKE_COLLECTION_FILE, 'a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerows(sample_collection_bikes)

# Hash password for security
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Check if user is logged in
def is_logged_in():
    return 'user_id' in session or 'admin' in session

# Check if user is admin
def is_admin():
    return 'admin' in session

# Routes

# Home page - redirect to appropriate page based on authentication
@app.route('/')
def home():
    if not is_logged_in():
        return render_template('index.html')
    elif is_admin():
        return redirect('/admin')
    else:
        return redirect('/dashboard')

# Main landing page
@app.route('/index')
def index():
    return render_template('index.html')

# Login page
@app.route('/login')
def login():
    if is_logged_in():
        if is_admin():
            return redirect('/admin')
        else:
            return redirect('/dashboard')
    return render_template('login.html')

# Register page
@app.route('/register')
def register():
    if is_logged_in():
        if is_admin():
            return redirect('/admin')
        else:
            return redirect('/dashboard')
    return render_template('register.html')

# Admin login page
@app.route('/admin-login')
def admin_login():
    if is_logged_in():
        if is_admin():
            return redirect('/admin')
        else:
            return redirect('/dashboard')
    return render_template('admin_login.html')

# User dashboard
@app.route('/dashboard')
def dashboard():
    if not is_logged_in():
        return redirect('/login')
    if is_admin():
        return redirect('/admin')
    return render_template('dashboard.html')

# Bikes page
@app.route('/bikes')
def bikes():
    if not is_logged_in():
        return redirect('/login')
    return render_template('bikes.html')

# Collection page
@app.route('/collection')
def collection():
    if not is_logged_in():
        return redirect('/login')
    return render_template('collection.html')

# Dealers page
@app.route('/dealers')
def dealers():
    if not is_logged_in():
        return redirect('/login')
    return render_template('dealers.html')

# Admin panel
@app.route('/admin')
def admin_panel():
    if not is_logged_in() or not is_admin():
        return redirect('/admin-login')
    return render_template('admin_panel.html')

# API Routes

# User registration endpoint
@app.route('/api/register', methods=['POST'])
def api_register():
    try:
        data = request.json
        name = data.get('name')
        email = data.get('email')
        phone = data.get('phone')
        password = data.get('password')
        
        # Check if user already exists
        with open(USERS_FILE, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['email'] == email:
                    return jsonify({'success': False, 'message': 'User already exists'})
        
        # Generate user ID
        with open(USERS_FILE, 'r', encoding='utf-8') as file:
            reader = csv.reader(file)
            user_count = sum(1 for row in reader) - 1
        
        user_id = user_count + 1
        
        # Add user to CSV
        with open(USERS_FILE, 'a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow([
                user_id, 
                name, 
                email, 
                phone, 
                hash_password(password), 
                datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            ])
        
        # Auto login after registration
        session['user_id'] = str(user_id)
        session['user_name'] = name
        session['user_email'] = email
        
        return jsonify({'success': True, 'message': 'Registration successful', 'user_id': user_id})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# User login endpoint
@app.route('/api/login', methods=['POST'])
def api_login():
    try:
        data = request.json
        email = data.get('email')
        password = data.get('password')
        
        # Check credentials
        with open(USERS_FILE, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['email'] == email and row['password_hash'] == hash_password(password):
                    session['user_id'] = row['user_id']
                    session['user_name'] = row['name']
                    session['user_email'] = email
                    return jsonify({
                        'success': True, 
                        'message': 'Login successful', 
                        'user_id': row['user_id'],
                        'user_name': row['name']
                    })
        
        return jsonify({'success': False, 'message': 'Invalid credentials'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Admin login endpoint
@app.route('/api/admin/login', methods=['POST'])
def api_admin_login():
    try:
        data = request.json
        username = data.get('username')
        password = data.get('password')
        
        # Check admin credentials
        if username in ADMINS and ADMINS[username] == password:
            session['admin'] = True
            session['admin_username'] = username
            return jsonify({'success': True, 'message': 'Admin login successful'})
        
        return jsonify({'success': False, 'message': 'Invalid admin credentials'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Logout endpoint
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

# Get current user info
@app.route('/api/user/info')
def api_user_info():
    if 'user_id' in session:
        return jsonify({
            'success': True,
            'user': {
                'id': session['user_id'],
                'name': session['user_name'],
                'email': session['user_email'],
                'type': 'user'
            }
        })
    elif 'admin' in session:
        return jsonify({
            'success': True,
            'user': {
                'id': 'admin',
                'name': session['admin_username'],
                'type': 'admin'
            }
        })
    else:
        return jsonify({'success': False, 'message': 'Not logged in'})

# Get current bikes
@app.route('/api/bikes/current')
def api_current_bikes():
    try:
        bikes = []
        with open(CURRENT_BIKES_FILE, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                row['features'] = json.loads(row.get('features', '[]'))
                bikes.append(row)
        
        return jsonify({'success': True, 'bikes': bikes})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Get bike collection
@app.route('/api/bikes/collection')
def api_bike_collection():
    try:
        filter_type = request.args.get('type', 'all')
        search_query = request.args.get('search', '')
        bikes = []
        
        with open(BIKE_COLLECTION_FILE, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if filter_type == 'all' or row['type'] == filter_type:
                    if not search_query or search_query.lower() in row['name'].lower() or search_query.lower() in row['brand'].lower():
                        row['features'] = json.loads(row.get('features', '[]'))
                        bikes.append(row)
        
        return jsonify({'success': True, 'bikes': bikes})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Get districts
@app.route('/api/districts')
def api_districts():
    try:
        districts = []
        with open(DISTRICTS_FILE, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                districts.append(row)
        
        return jsonify({'success': True, 'districts': districts})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Add bike to collection (Admin only)
@app.route('/api/admin/bikes/add', methods=['POST'])
def api_add_bike():
    try:
        if 'admin' not in session:
            return jsonify({'success': False, 'message': 'Admin access required'})
        
        data = request.json
        required_fields = ['name', 'price', 'image_url', 'engine', 'mileage', 'type', 'brand', 'description']
        
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'message': f'Missing required field: {field}'})
        
        # Generate bike ID
        with open(BIKE_COLLECTION_FILE, 'r', encoding='utf-8') as file:
            reader = csv.reader(file)
            bike_count = sum(1 for row in reader) - 1
        
        bike_id = bike_count + 1
        
        # Prepare features as JSON string
        features = json.dumps(data.get('features', []))
        status = data.get('status', 'available')
        
        # Add bike to collection
        with open(BIKE_COLLECTION_FILE, 'a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow([
                bike_id,
                data['name'],
                data['price'],
                data['image_url'],
                data['engine'],
                data['mileage'],
                data['type'],
                data['brand'],
                data['description'],
                features,
                status,
                datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            ])
        
        return jsonify({'success': True, 'message': 'Bike added to collection successfully', 'bike_id': bike_id})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Add to favorites
@app.route('/api/favorites/add', methods=['POST'])
def api_add_favorite():
    try:
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': 'Please login first'})
        
        data = request.json
        bike_id = data.get('bike_id')
        user_id = session['user_id']
        
        # Check if already in favorites
        with open(FAVORITES_FILE, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['user_id'] == user_id and row['bike_id'] == bike_id:
                    return jsonify({'success': False, 'message': 'Bike already in favorites'})
        
        # Add to favorites
        with open(FAVORITES_FILE, 'a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow([
                user_id, 
                bike_id, 
                datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            ])
        
        return jsonify({'success': True, 'message': 'Bike added to favorites'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Get user favorites
@app.route('/api/favorites')
def api_get_favorites():
    try:
        if 'user_id' not in session:
            return jsonify({'success': False, 'message': 'Please login first'})
        
        user_id = session['user_id']
        favorites = []
        
        # Get favorite bike IDs
        with open(FAVORITES_FILE, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            favorite_bike_ids = [row['bike_id'] for row in reader if row['user_id'] == user_id]
        
        # Get bike details from both collections
        all_bikes = []
        
        # From current bikes
        with open(CURRENT_BIKES_FILE, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['bike_id'] in favorite_bike_ids:
                    row['features'] = json.loads(row.get('features', '[]'))
                    all_bikes.append(row)
        
        # From collection
        with open(BIKE_COLLECTION_FILE, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['bike_id'] in favorite_bike_ids:
                    row['features'] = json.loads(row.get('features', '[]'))
                    all_bikes.append(row)
        
        return jsonify({'success': True, 'favorites': all_bikes})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Get admin stats
@app.route('/api/admin/stats')
def api_admin_stats():
    try:
        if 'admin' not in session:
            return jsonify({'success': False, 'message': 'Admin access required'})
        
        stats = {}
        
        # Get users count
        with open(USERS_FILE, 'r', encoding='utf-8') as file:
            reader = csv.reader(file)
            stats['users_count'] = sum(1 for row in reader) - 1
        
        # Get bikes count
        with open(BIKE_COLLECTION_FILE, 'r', encoding='utf-8') as file:
            reader = csv.reader(file)
            stats['bikes_count'] = sum(1 for row in reader) - 1
        
        # Get favorites count
        with open(FAVORITES_FILE, 'r', encoding='utf-8') as file:
            reader = csv.reader(file)
            stats['favorites_count'] = sum(1 for row in reader) - 1
        
        return jsonify({'success': True, 'stats': stats})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Record brochure download
@app.route('/api/brochure/download', methods=['POST'])
def api_record_brochure_download():
    try:
        data = request.json
        bike_id = data.get('bike_id')
        user_id = session.get('user_id', 'guest')
        
        # Generate request ID
        with open(BROCHURE_REQUESTS_FILE, 'r', encoding='utf-8') as file:
            reader = csv.reader(file)
            request_count = sum(1 for row in reader) - 1
        
        request_id = request_count + 1
        
        # Record brochure request
        with open(BROCHURE_REQUESTS_FILE, 'a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow([
                request_id,
                user_id,
                bike_id,
                datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                1  # download_count
            ])
        
        return jsonify({'success': True, 'message': 'Brochure download recorded'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

# Initialize CSV files when the app starts
init_csv_files()

if __name__ == '__main__':
    app.run(debug=True, port=5000)